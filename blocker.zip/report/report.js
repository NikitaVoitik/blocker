(function () {
  const shameLevels = [
    { min: 0, label: 'Clean' },
    { min: 1, label: 'Rookie' },
    { min: 3, label: 'Repeat Offender' },
    { min: 6, label: 'Addict' },
    { min: 10, label: 'Terminal Brain Rot' },
    { min: 20, label: 'Beyond Saving' }
  ];

  function getShameLevel(threeDayCount) {
    let level = shameLevels[0].label;
    for (const s of shameLevels) {
      if (threeDayCount >= s.min) level = s.label;
    }
    return level;
  }

  function formatDate(dateStr) {
    const parts = dateStr.split('-');
    return parts[1] + '/' + parts[2];
  }

  function renderDailyChart(dailyBreakdown) {
    const container = document.getElementById('daily-chart');
    const axis = document.getElementById('chart-axis');
    const maxCount = Math.max(1, ...dailyBreakdown.map(d => d.count));

    for (let i = 0; i < dailyBreakdown.length; i++) {
      const entry = dailyBreakdown[i];
      const bar = document.createElement('div');
      bar.className = 'bar';

      if (entry.count === 0) {
        bar.classList.add('bar-zero');
      } else {
        const heightPct = (entry.count / maxCount) * 100;
        bar.style.height = heightPct + '%';
        const opacity = 0.4 + (entry.count / maxCount) * 0.6;
        bar.style.backgroundColor = `rgba(255, 51, 51, ${opacity})`;
      }

      const tooltip = document.createElement('span');
      tooltip.className = 'bar-tooltip';
      tooltip.textContent = entry.count;
      bar.appendChild(tooltip);

      bar.setAttribute('data-date', formatDate(entry.date));
      container.appendChild(bar);
    }

    // Axis labels: first, middle, last
    const first = document.createElement('span');
    first.textContent = formatDate(dailyBreakdown[0].date);
    const mid = document.createElement('span');
    mid.textContent = formatDate(dailyBreakdown[14].date);
    const last = document.createElement('span');
    last.textContent = formatDate(dailyBreakdown[29].date);
    axis.appendChild(first);
    axis.appendChild(mid);
    axis.appendChild(last);
  }

  function renderWeeklyChart(weeklySummaries) {
    const container = document.getElementById('weekly-chart');
    const labels = ['This Week', 'Last Week', '2 Weeks Ago', '3 Weeks Ago'];
    const maxTotal = Math.max(1, ...weeklySummaries.map(w => w.total));

    for (let i = 0; i < weeklySummaries.length; i++) {
      const week = weeklySummaries[i];
      const row = document.createElement('div');
      row.className = 'week-row';

      const label = document.createElement('span');
      label.className = 'week-label';
      label.textContent = labels[i];

      const track = document.createElement('div');
      track.className = 'week-bar-track';

      const bar = document.createElement('div');
      bar.className = 'week-bar';
      const widthPct = (week.total / maxTotal) * 100;
      bar.style.width = widthPct + '%';
      const opacity = week.total > 0 ? 0.4 + (week.total / maxTotal) * 0.6 : 0;
      bar.style.backgroundColor = `rgba(255, 51, 51, ${opacity})`;

      track.appendChild(bar);

      const count = document.createElement('span');
      count.className = 'week-count';
      count.textContent = week.total;

      row.appendChild(label);
      row.appendChild(track);
      row.appendChild(count);
      container.appendChild(row);
    }
  }

  function populate(data) {
    document.getElementById('today-count').textContent = data.todayCount;
    document.getElementById('seven-day-count').textContent = data.sevenDayCount;
    document.getElementById('thirty-day-count').textContent = data.thirtyDayCount;
    document.getElementById('all-time-count').textContent = data.allTimeCount;

    const worstLabel = data.worstDay.count > 0
      ? formatDate(data.worstDay.date) + ' (' + data.worstDay.count + ')'
      : 'None';
    document.getElementById('worst-day').textContent = worstLabel;
    document.getElementById('current-streak').textContent = data.currentCleanStreak + ' day' + (data.currentCleanStreak !== 1 ? 's' : '');
    document.getElementById('longest-streak').textContent = data.longestCleanStreak + ' day' + (data.longestCleanStreak !== 1 ? 's' : '');
    document.getElementById('photo-count').textContent = data.photoCount;
    document.getElementById('shame-level').textContent = getShameLevel(data.threeDayCount);

    renderDailyChart(data.dailyBreakdown);
    renderWeeklyChart(data.weeklySummaries);
  }

  chrome.runtime.sendMessage({ type: 'GET_REPORT_DATA' }, (response) => {
    if (response) {
      populate(response);
    }
  });
})();
