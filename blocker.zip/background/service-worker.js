// Service Worker - Coordinates capture, storage, and messaging

const OFFSCREEN_DOCUMENT_PATH = 'offscreen/offscreen.html';

const DEFAULT_SITES = [
  {
    id: 'twitter',
    label: 'Twitter / X',
    domains: ['twitter.com', 'x.com', 'www.twitter.com', 'www.x.com', 'mobile.twitter.com', 'mobile.x.com'],
    builtin: true
  },
  {
    id: 'youtube-shorts',
    label: 'YouTube Shorts',
    domains: ['youtube.com/shorts', 'www.youtube.com/shorts', 'm.youtube.com/shorts'],
    pathOnly: true,
    builtin: true
  }
];

// Runtime cache of blocked sites
let currentBlockedSites = [];

// Load blocked sites from storage
async function loadBlockedSites() {
  const result = await chrome.storage.local.get('blockedSites');
  currentBlockedSites = result.blockedSites || DEFAULT_SITES;
  return currentBlockedSites;
}

// Save blocked sites to storage and sync rules
async function saveBlockedSites(sites) {
  currentBlockedSites = sites;
  await chrome.storage.local.set({ blockedSites: sites });
  await syncBlockRules();
}

// Generate dynamic declarativeNetRequest rules from blocked sites
async function syncBlockRules() {
  const sites = currentBlockedSites;
  const rules = [];
  let ruleId = 1000; // Start high to avoid conflicts with static rules

  for (const site of sites) {
    for (const domain of site.domains) {
      rules.push({
        id: ruleId++,
        priority: 1,
        action: {
          type: 'redirect',
          redirect: {
            extensionPath: `/blocked/blocked.html?site=${encodeURIComponent(site.id)}`
          }
        },
        condition: {
          urlFilter: `||${domain}`,
          resourceTypes: ['main_frame']
        }
      });
    }
  }

  // Get existing dynamic rules to remove them
  const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
  const removeRuleIds = existingRules.map(r => r.id);

  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds,
    addRules: rules
  });
}

// Check if a URL matches any blocked site
function getMatchingSite(url) {
  try {
    const parsed = new URL(url);
    for (const site of currentBlockedSites) {
      if (site.pathOnly) {
        for (const domain of site.domains) {
          const [host, ...pathParts] = domain.split('/');
          const path = '/' + pathParts.join('/');
          if (parsed.hostname === host && parsed.pathname.startsWith(path)) {
            return site;
          }
        }
      } else {
        if (site.domains.includes(parsed.hostname)) {
          return site;
        }
      }
    }
  } catch (e) {
    // Invalid URL
  }
  return null;
}

// Block sites via webNavigation API (backup for declarativeNetRequest)
chrome.webNavigation.onBeforeNavigate.addListener(async (details) => {
  if (details.frameId !== 0) return;

  const site = getMatchingSite(details.url);
  if (site) {
    await chrome.tabs.update(details.tabId, {
      url: chrome.runtime.getURL(`blocked/blocked.html?site=${encodeURIComponent(site.id)}`)
    });
  }
});

const DB_NAME = 'SelfieShameDB';
const DB_VERSION = 1;
const PHOTOS_STORE = 'photos';
const MAX_PHOTOS = 50;

// IndexedDB instance
let db = null;

// Open IndexedDB
async function openDatabase() {
  if (db) return db;

  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      db = request.result;
      resolve(db);
    };

    request.onupgradeneeded = (event) => {
      const database = event.target.result;
      if (!database.objectStoreNames.contains(PHOTOS_STORE)) {
        const store = database.createObjectStore(PHOTOS_STORE, {
          keyPath: 'id',
          autoIncrement: true
        });
        store.createIndex('timestamp', 'timestamp', { unique: false });
      }
    };
  });
}

// Save photo to IndexedDB
async function savePhoto(dataUrl) {
  const database = await openDatabase();

  return new Promise((resolve, reject) => {
    const transaction = database.transaction([PHOTOS_STORE], 'readwrite');
    const store = transaction.objectStore(PHOTOS_STORE);

    const photo = {
      data: dataUrl,
      timestamp: Date.now()
    };

    const request = store.add(photo);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);

    // Cleanup old photos after adding
    transaction.oncomplete = () => cleanupOldPhotos();
  });
}

// Get all photos
async function getPhotos() {
  const database = await openDatabase();

  return new Promise((resolve, reject) => {
    const transaction = database.transaction([PHOTOS_STORE], 'readonly');
    const store = transaction.objectStore(PHOTOS_STORE);
    const request = store.getAll();

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

// Cleanup old photos (keep only MAX_PHOTOS)
async function cleanupOldPhotos() {
  const database = await openDatabase();

  return new Promise((resolve) => {
    const transaction = database.transaction([PHOTOS_STORE], 'readwrite');
    const store = transaction.objectStore(PHOTOS_STORE);
    const index = store.index('timestamp');

    const request = index.openCursor(null, 'prev');
    const toDelete = [];
    let count = 0;

    request.onsuccess = (event) => {
      const cursor = event.target.result;
      if (cursor) {
        count++;
        if (count > MAX_PHOTOS) {
          toDelete.push(cursor.primaryKey);
        }
        cursor.continue();
      } else {
        // Delete old photos
        toDelete.forEach(key => store.delete(key));
        resolve();
      }
    };

    request.onerror = () => resolve();
  });
}

// Get today's date key in YYYY-MM-DD format
function getTodayKey() {
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

// Sum dailyCounts for the last n calendar days
function sumLastNDays(dailyCounts, n) {
  const today = new Date();
  let total = 0;
  for (let i = 0; i < n; i++) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const key = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    total += dailyCounts[key] || 0;
  }
  return total;
}

function sumLastThreeDays(dailyCounts) {
  return sumLastNDays(dailyCounts, 3);
}

// Prune dailyCounts entries older than 30 days
function pruneDailyCounts(dailyCounts) {
  const today = new Date();
  const validKeys = new Set();
  for (let i = 0; i < 30; i++) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    validKeys.add(d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'));
  }
  const pruned = {};
  for (const key of Object.keys(dailyCounts)) {
    if (validKeys.has(key)) pruned[key] = dailyCounts[key];
  }
  return pruned;
}

// Get/update attempt stats
async function getStats() {
  const result = await chrome.storage.local.get(['attemptCount', 'todayDate', 'todayCount', 'dailyCounts']);

  const today = new Date().toDateString();
  let todayCount = result.todayCount || 0;

  // Reset today count if it's a new day
  if (result.todayDate !== today) {
    todayCount = 0;
    await chrome.storage.local.set({ todayDate: today, todayCount: 0 });
  }

  let dailyCounts = result.dailyCounts || {};

  // Migrate: if dailyCounts was never written, seed today's entry from todayCount
  const todayKey = getTodayKey();
  if (Object.keys(dailyCounts).length === 0 && todayCount > 0) {
    dailyCounts[todayKey] = todayCount;
    await chrome.storage.local.set({ dailyCounts });
  }

  const threeDayCount = sumLastThreeDays(dailyCounts);

  return {
    allTimeCount: result.attemptCount || 0,
    todayCount: todayCount,
    threeDayCount: threeDayCount
  };
}

async function incrementAttempt() {
  const result = await chrome.storage.local.get(['attemptCount', 'todayDate', 'todayCount', 'dailyCounts']);

  const today = new Date().toDateString();
  let todayCount = result.todayCount || 0;

  // Reset today count if it's a new day
  if (result.todayDate !== today) {
    todayCount = 0;
  }

  const newAllTime = (result.attemptCount || 0) + 1;
  const newToday = todayCount + 1;

  // Update dailyCounts
  const todayKey = getTodayKey();
  let dailyCounts = result.dailyCounts || {};
  dailyCounts[todayKey] = (dailyCounts[todayKey] || 0) + 1;
  dailyCounts = pruneDailyCounts(dailyCounts);

  await chrome.storage.local.set({
    attemptCount: newAllTime,
    todayDate: today,
    todayCount: newToday,
    dailyCounts: dailyCounts
  });

  return { allTimeCount: newAllTime, todayCount: newToday, threeDayCount: sumLastThreeDays(dailyCounts) };
}

// Check if offscreen document exists
async function hasOffscreenDocument() {
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
    documentUrls: [chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH)]
  });
  return contexts.length > 0;
}

// Create offscreen document
async function createOffscreenDocument() {
  if (await hasOffscreenDocument()) {
    return;
  }

  await chrome.offscreen.createDocument({
    url: OFFSCREEN_DOCUMENT_PATH,
    reasons: ['USER_MEDIA'],
    justification: 'Capture webcam photo for shame display'
  });
}

// Close offscreen document
async function closeOffscreenDocument() {
  if (await hasOffscreenDocument()) {
    await chrome.offscreen.closeDocument();
  }
}

// Capture photo via offscreen document
async function capturePhoto() {
  try {
    await createOffscreenDocument();

    // Small delay to ensure document is ready
    await new Promise(resolve => setTimeout(resolve, 200));

    const response = await chrome.runtime.sendMessage({ type: 'CAPTURE_PHOTO' });

    if (response && response.success) {
      // Save photo and increment attempt
      await savePhoto(response.data);
      await incrementAttempt();
      await closeOffscreenDocument();

      return response;
    }

    await closeOffscreenDocument();
    return { success: false, error: 'Capture failed' };
  } catch (error) {
    console.error('Capture error:', error);
    await closeOffscreenDocument();
    return { success: false, error: error.message };
  }
}

// Add a blocked site
async function addBlockedSite(siteEntry) {
  const sites = [...currentBlockedSites];

  // Check for duplicate
  if (sites.some(s => s.id === siteEntry.id)) {
    return { success: false, error: 'Site already blocked' };
  }

  sites.push(siteEntry);
  await saveBlockedSites(sites);
  return { success: true, sites };
}

// Remove a blocked site
async function removeBlockedSite(siteId) {
  const sites = currentBlockedSites.filter(s => s.id !== siteId);
  await saveBlockedSites(sites);
  return { success: true, sites };
}

// Handle messages from content scripts and popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Ignore messages from offscreen document (it handles CAPTURE_PHOTO internally)
  if (sender.url && sender.url.includes('offscreen/offscreen.html')) {
    return false;
  }

  if (message.type === 'CAPTURE_PHOTO') {
    capturePhoto().then(sendResponse);
    return true; // Async response
  }

  if (message.type === 'GET_STATS') {
    getStats().then(sendResponse);
    return true;
  }

  if (message.type === 'GET_PHOTOS') {
    getPhotos().then(sendResponse);
    return true;
  }

  if (message.type === 'GET_REPORT_DATA') {
    (async () => {
      const result = await chrome.storage.local.get(['attemptCount', 'todayDate', 'todayCount', 'dailyCounts', 'installDate']);
      const dailyCounts = result.dailyCounts || {};
      const photos = await getPhotos();

      const today = new Date();
      const dailyBreakdown = [];
      for (let i = 29; i >= 0; i--) {
        const d = new Date(today);
        d.setDate(d.getDate() - i);
        const key = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
        dailyBreakdown.push({ date: key, count: dailyCounts[key] || 0 });
      }

      const weeklySummaries = [];
      for (let w = 0; w < 4; w++) {
        let weekTotal = 0;
        for (let i = 0; i < 7; i++) {
          const d = new Date(today);
          d.setDate(d.getDate() - (w * 7 + i));
          const key = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
          weekTotal += dailyCounts[key] || 0;
        }
        weeklySummaries.push({ weekNumber: w + 1, total: weekTotal });
      }

      let worstDay = { date: 'N/A', count: 0 };
      for (const entry of dailyBreakdown) {
        if (entry.count > worstDay.count) worstDay = entry;
      }

      // Only count streaks from install date onward
      const installDate = result.installDate || dailyBreakdown[dailyBreakdown.length - 1].date;
      const activeDays = dailyBreakdown.filter(d => d.date >= installDate);

      let currentStreak = 0;
      for (let i = activeDays.length - 1; i >= 0; i--) {
        if (activeDays[i].count === 0) currentStreak++;
        else break;
      }

      let longestStreak = 0, tempStreak = 0;
      for (const entry of activeDays) {
        if (entry.count === 0) { tempStreak++; longestStreak = Math.max(longestStreak, tempStreak); }
        else tempStreak = 0;
      }

      sendResponse({
        allTimeCount: result.attemptCount || 0,
        todayCount: result.todayCount || 0,
        threeDayCount: sumLastNDays(dailyCounts, 3),
        sevenDayCount: sumLastNDays(dailyCounts, 7),
        thirtyDayCount: sumLastNDays(dailyCounts, 30),
        dailyBreakdown,
        weeklySummaries,
        worstDay,
        currentCleanStreak: currentStreak,
        longestCleanStreak: longestStreak,
        photoCount: photos.length
      });
    })();
    return true;
  }

  if (message.type === 'GET_BLOCKED_SITES') {
    initReady.then(() => sendResponse(currentBlockedSites));
    return true;
  }

  if (message.type === 'ADD_BLOCKED_SITE') {
    addBlockedSite(message.site).then(sendResponse);
    return true;
  }

  if (message.type === 'REMOVE_BLOCKED_SITE') {
    removeBlockedSite(message.siteId).then(sendResponse);
    return true;
  }

  if (message.type === 'GET_AVAILABLE_PRESETS') {
    initReady.then(() => {
      const blockedIds = new Set(currentBlockedSites.map(s => s.id));
      sendResponse(DEFAULT_SITES.filter(s => !blockedIds.has(s.id)));
    });
    return true;
  }

  return false;
});

// Refresh cache when storage changes
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.blockedSites) {
    currentBlockedSites = changes.blockedSites.newValue || [];
  }
});

// On install, seed default sites and open setup page
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === 'install') {
    await chrome.storage.local.set({ installDate: getTodayKey() });
    await saveBlockedSites(DEFAULT_SITES);
    await chrome.tabs.create({
      url: chrome.runtime.getURL('setup/setup.html')
    });
  } else {
    // On update, load existing sites and sync rules
    await loadBlockedSites();
    await syncBlockRules();
  }
});

// Initialize on startup
async function initialize() {
  await openDatabase().catch(console.error);
  await loadBlockedSites();
  await syncBlockRules();
}

const initReady = initialize();
