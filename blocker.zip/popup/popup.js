// Popup script

const allTimeEl = document.getElementById('all-time');
const threeDayEl = document.getElementById('three-day');
const todayEl = document.getElementById('today');
const photosEl = document.getElementById('photos');
const shameLevelEl = document.getElementById('shame-level');
const shameLevelContainer = document.querySelector('.shame-level');
const viewGalleryBtn = document.getElementById('view-gallery');
const viewReportBtn = document.getElementById('view-report');
const testBlockBtn = document.getElementById('test-block');
const blockedListEl = document.getElementById('blocked-list');
const siteInput = document.getElementById('site-input');
const addSiteBtn = document.getElementById('add-site-btn');

const shameLevels = [
  { min: 0, name: 'Clean', class: 'level-1' },
  { min: 1, name: 'Rookie', class: 'level-1' },
  { min: 3, name: 'Repeat Offender', class: 'level-2' },
  { min: 6, name: 'Addict', class: 'level-3' },
  { min: 10, name: 'Terminal Brain Rot', class: 'level-4' },
  { min: 20, name: 'Beyond Saving', class: 'level-5' }
];

function getShameLevel(count) {
  let level = shameLevels[0];
  for (const l of shameLevels) {
    if (count >= l.min) level = l;
  }
  return level;
}

function extractHostname(input) {
  let cleaned = input.trim().toLowerCase();
  // Strip protocol
  cleaned = cleaned.replace(/^https?:\/\//, '');
  // Strip trailing slash and path
  cleaned = cleaned.replace(/\/.*$/, '');
  // Strip www. prefix for the id but keep it for domains
  return cleaned;
}

async function loadBlockedSites() {
  const sites = await chrome.runtime.sendMessage({ type: 'GET_BLOCKED_SITES' });
  renderBlockedSites(sites || []);
  await loadAvailablePresets();
}

async function loadAvailablePresets() {
  const presets = await chrome.runtime.sendMessage({ type: 'GET_AVAILABLE_PRESETS' });
  renderPresetSuggestions(presets || []);
}

function renderPresetSuggestions(presets) {
  let container = document.getElementById('preset-suggestions');
  if (container) container.remove();

  if (presets.length === 0) return;

  container = document.createElement('div');
  container.id = 'preset-suggestions';
  container.className = 'preset-suggestions';

  const heading = document.createElement('h3');
  heading.textContent = 'Available presets';
  container.appendChild(heading);

  for (const preset of presets) {
    const item = document.createElement('div');
    item.className = 'preset-item';

    const label = document.createElement('span');
    label.className = 'preset-label';
    label.textContent = preset.label || preset.id;

    const addBtn = document.createElement('button');
    addBtn.className = 'preset-add';
    addBtn.textContent = '+';
    addBtn.title = 'Add';
    addBtn.addEventListener('click', async () => {
      const result = await chrome.runtime.sendMessage({ type: 'ADD_BLOCKED_SITE', site: preset });
      if (result && result.success) await loadBlockedSites();
    });

    item.appendChild(label);
    item.appendChild(addBtn);
    container.appendChild(item);
  }

  blockedListEl.parentElement.insertBefore(container, blockedListEl.nextSibling);
}

function renderBlockedSites(sites) {
  blockedListEl.innerHTML = '';
  for (const site of sites) {
    const item = document.createElement('div');
    item.className = 'site-item';

    const label = document.createElement('span');
    label.className = 'site-label';
    label.textContent = site.label || site.id;

    const removeBtn = document.createElement('button');
    removeBtn.className = 'site-remove';
    removeBtn.textContent = '\u00d7';
    removeBtn.title = 'Remove';
    removeBtn.addEventListener('click', () => removeSite(site.id));

    item.appendChild(label);
    item.appendChild(removeBtn);
    blockedListEl.appendChild(item);
  }
}

async function addSite() {
  const raw = siteInput.value;
  if (!raw.trim()) return;

  const hostname = extractHostname(raw);
  if (!hostname || !hostname.includes('.')) return;

  const id = hostname.replace(/^www\./, '');
  const domains = [hostname];
  if (!hostname.startsWith('www.')) {
    domains.push('www.' + hostname);
  }

  const site = {
    id,
    label: id,
    domains,
    builtin: false
  };

  const result = await chrome.runtime.sendMessage({ type: 'ADD_BLOCKED_SITE', site });
  if (result && result.success) {
    siteInput.value = '';
    await loadBlockedSites();
  }
}

async function removeSite(siteId) {
  const result = await chrome.runtime.sendMessage({ type: 'REMOVE_BLOCKED_SITE', siteId });
  if (result && result.success) {
    await loadBlockedSites();
  }
}

async function loadStats() {
  try {
    const stats = await chrome.runtime.sendMessage({ type: 'GET_STATS' });
    const photos = await chrome.runtime.sendMessage({ type: 'GET_PHOTOS' });

    const allTime = stats?.allTimeCount || 0;
    const threeDayCount = stats?.threeDayCount || 0;
    const today = stats?.todayCount || 0;
    const photoCount = photos?.length || 0;

    allTimeEl.textContent = allTime;
    threeDayEl.textContent = threeDayCount;
    todayEl.textContent = today;
    photosEl.textContent = photoCount;

    const level = getShameLevel(threeDayCount);
    shameLevelEl.textContent = level.name;
    shameLevelContainer.className = 'shame-level ' + level.class;
  } catch (error) {
    console.error('Failed to load stats:', error);
  }
}

addSiteBtn.addEventListener('click', addSite);

siteInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') addSite();
});

viewGalleryBtn.addEventListener('click', () => {
  chrome.tabs.create({
    url: chrome.runtime.getURL('blocked/blocked.html?gallery=true')
  });
});

viewReportBtn.addEventListener('click', () => {
  chrome.tabs.create({
    url: chrome.runtime.getURL('report/report.html')
  });
});

testBlockBtn.addEventListener('click', () => {
  chrome.tabs.create({
    url: chrome.runtime.getURL('blocked/blocked.html')
  });
});

// Load on popup open
loadStats();
loadBlockedSites();
